#include<stdio.h>  
int main()  
{  
     system("ps -l");
     printf("this is the cmd1\n");  
     return 0;  
}  
