#include<stdio.h>  
int main()  
{  
     system("touch test.c");//系统调用，创建test.c
     printf("this is the cmd2\n");  
     return 0;  
}  
