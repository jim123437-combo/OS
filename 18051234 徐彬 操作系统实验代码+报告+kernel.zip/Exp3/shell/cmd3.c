#include<stdio.h>  
int main()  
{  
     system("rm -rf test.c");//系统调用，移除test.c
     printf("this is the cmd3\n");  
     return 0;  
}  
